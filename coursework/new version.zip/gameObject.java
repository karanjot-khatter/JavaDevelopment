import java.util.Set;
import java.util.HashSet;
/**
 * Write a description of class Item here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class gameObject
{
    // instance variables - replace the example below with your own
    private Set objects;
    private boolean pickable;
    private int weight;
    private String description;
    private String name;
    private gameObject location;

    /**
     * Constructor for objects of class Item
     */
    public gameObject()
    {
        this.objects = new HashSet();
        this.name = name;
        pickable = false;
        weight = 0;
    }

   public Set getObjects()
   {
       return this.objects;
   }
   
   public boolean isPickable()
   {
       return pickable;
    }
    
    public void setPickable(boolean b)
    {
        pickable = b;
    }
    
     public String getName()
    {
         return name;
    }
             
    public int getItemWeight()
    {
        return weight;
    }
    
    public void setWeight(int w)
    {
        weight = w;
    }
    
  }